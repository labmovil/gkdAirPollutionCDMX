<?php

require("postgresql.php");

$query = 'SELECT DISTINCT "CIUDAD" FROM public."proyectoHoneywell"';

$queryAll = 'SELECT * FROM public."proyectoHoneywell"';

$resultado = pg_query($conexion, $query) or die("Error en la Consulta SQL");
$numReg = pg_num_rows($resultado);

if($numReg > 0){

  echo '<table>';
  	echo '<thead>';
		  echo '<tr>';
  			$i = 0;
			  while ($fila = pg_fetch_array($resultado)) {   
			  	$array[$i] = $fila['CIUDAD'];
			    echo '<th>' . $fila['CIUDAD'] . '</th>';
			    $i++;
			  } 
		  echo '</tr>';
	echo '</thead>';

	echo '<tbody>'; 

	$resultadoQueryAll = pg_query($conexion, $queryAll) or die("Error en la Consulta SQL");
	$numRegQueryAll = pg_num_rows($resultadoQueryAll);
	if($numRegQueryAll > 0){
		
			while ($fila = pg_fetch_array($resultadoQueryAll)) {  
				echo '<tr>'; 
			  	for($j=0; $j<$i; $j++){
			  		if($fila['CIUDAD'] == $array[$j]){
			  			echo '<td>' .'1'. '</td>';
			  		}else{
			  			echo '<td>' .'0'. '</td>';
			  		}
			  	}
			    echo '</tr>';
		  	} 
		
	}

	echo '</tbody>'; 
  echo '</table>';  
}

/*echo "Elementos del array [".$i.']:';

for($j = 0; $j < $i; $j++){
	echo '<p>'.$array[$j].'</p>';
}*/
pg_close($conexion);

?>
