<?php
echo header("Content-type: text/xml");

require("postgresql.php");

$query = 'SELECT * FROM rutasClientesRating';

$resultado = pg_query($conexion, $query) or die("Error en la Consulta SQL");
$numReg = pg_num_rows($resultado);


if($numReg > 0){

  echo '<markers>';

  while ($fila = pg_fetch_array($resultado)) {   
    echo '<marker ';
    echo ' ID_RUTA = "' . $fila['ID_RUTA'] . '" ';
    echo ' ID_CLIENTE = "' . $fila['ID_CLIENTE'] . '" ';
    echo ' ESTADO = "' . $fila['ESTADO'] . '" ';
    echo ' CIUDAD = "' . $fila['CIUDAD'] . '" ';
    echo ' CODIGO_POSTAL = "' . $fila['CODIGO_POSTAL'] . '" ';
    echo ' CALLE = "' . $fila['CALLE'] . '" ';
    echo ' PROMEDIO_RATING = "' . $fila['PROMEDIO_RATING'] . '" ';
    echo ' LATITUD = "' . $fila['LATITUD'] . '" ';
    echo ' LONGITUD = "' . $fila['LONGITUD'] . '" ';

    echo ' />';
  } 

  echo '</markers>';  
}else{
  echo "No hay Registros";
}

pg_close($conexion);
?>
