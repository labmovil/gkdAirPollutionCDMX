

$(document).ready(function() {
  //Crear tabla a partir de un xml

  initMap();

  createTable();

});

var map;
var markers = [];
var labels = [];

function initMap(){
  
  var myStyle = [{
      featureType: "administrative",
      elementType: "labels",
      stylers: [{
        visibility: "on"
      }]
    }, {
      featureType: "water",
      elementType: "labels",
      stylers: [{
        visibility: "off"
      }]
    }, {
      featureType: "road",
      elementType: "labels",
      stylers: [{
        visibility: "off"
      }]
    }, {
      featureType: "poi",
      elementType: "labels",
      stylers: [{
        visibility: "off"
      }]
    }];

map = new google.maps.Map(document.getElementById('map'), {
  center: new google.maps.LatLng(47.417646,-98.6514613),
  zoom: 4,
  disableDefaultUI: true,
  mapTypeControlOptions: {
    mapTypeIds: ['mystyle', google.maps.MapTypeId.ROADMAP, google.maps.MapTypeId.TERRAIN]
  }, mapTypeId: 'mystyle'
  });

map.mapTypes.set('mystyle', new google.maps.StyledMapType(myStyle, {
  name: 'My Style'
}));

  var controlUI = document.getElementById('floating-panel');
//controlUI.style.backgroundColor = '#fff';
  //controlUI.style.border = '10px solid #000000';
  controlUI.style.borderRadius = '1px';
//  controlUI.style.border-right: '1px solid';
  
  //controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
  controlUI.style.cursor = 'pointer';
  controlUI.style.marginBottom = '22px';
  controlUI.style.textAlign = 'center';
  controlUI.style.paddingLeft = '10px';
  controlUI.style['padding-top'] = '10px';

  var controlText_showMarkers = document.getElementById('showMarkers');
  controlText_showMarkers.style.backgroundColor = '#ffffff';
  //controlText_showMarkers.style.border = '0px solid #fff';
  controlText_showMarkers.style.color = 'rgb(25,25,25)';
  controlText_showMarkers.style.fontFamily = 'Roboto,Arial,sans-serif';
  controlText_showMarkers.style.fontSize = '10px';
  controlText_showMarkers.style.lineHeight = '22px';
  controlText_showMarkers.style.paddingLeft = '5px';
  controlText_showMarkers.style.paddingRight = '5px';

  var controlText_clearMarkers = document.getElementById('clearMarkers');
  controlText_clearMarkers.style.borderRight = '10px solid #000000';
  controlText_clearMarkers.style.backgroundColor = '#ffffff';
  controlText_clearMarkers.style.border = '0px solid #fff';
  controlText_clearMarkers.style.color = 'rgb(25,25,25)';
  controlText_clearMarkers.style.fontFamily = 'Roboto,Arial,sans-serif';
  controlText_clearMarkers.style.fontSize = '10px';
  controlText_clearMarkers.style.lineHeight = '22px';
  controlText_clearMarkers.style.paddingLeft = '5px';
  controlText_clearMarkers.style.paddingRight = '5px';

  controlUI.appendChild(controlText_clearMarkers);
  controlUI.appendChild(controlText_showMarkers);

  map.controls[google.maps.ControlPosition.TOP_LEFT].push(controlUI);

}

function clearMarkers() {
  setMapOnAll(null);
  markers = [];

}

function showMarkers() {
  initMarkers();
  setMapOnAll(map);

  var div_div_tabla = document.getElementById('div_div_tabla');
  div_div_tabla.setAttribute('style', 'visibility: visible;');
}

function setMapOnAll(map) {
  for (var i = 0; i < markers.length; i++) {
    markers[i].setMap(map);
  }
}

/*********************************************************************************************************************************/

function initMarkers(){
  downloadUrl('rutasClientes.xml', function(data) {
    var xml = data.responseXML;
    var markers = xml.documentElement.getElementsByTagName('marker');
    Array.prototype.forEach.call(markers, function(markerElem) {
      var ID_CLIENTE = markerElem.getAttribute('ID_CLIENTE');
      var ID_RUTA = markerElem.getAttribute('ID_RUTA');
      var ESTADO = markerElem.getAttribute('ESTADO');
      var CIUDAD =  markerElem.getAttribute('CIUDAD');
      var CODIGO_POSTAL = markerElem.getAttribute('CODIGO_POSTAL');
      var CALLE = markerElem.getAttribute('CALLE');
      var PROMEDIO_RATING = parseFloat(markerElem.getAttribute('PROMEDIO_RATING')).toFixed(1);

      var centro = new google.maps.LatLng(
        parseFloat(markerElem.getAttribute('LATITUD')),
        parseFloat(markerElem.getAttribute('LONGITUD'))
      );

    addMarker(centro, ID_CLIENTE, ID_RUTA, ESTADO, CIUDAD, CODIGO_POSTAL, CALLE, PROMEDIO_RATING);

    });
  });        
}

function addMarker(centro, ID_CLIENTE, ID_RUTA, ESTADO, CIUDAD, CODIGO_POSTAL, CALLE, PROMEDIO_RATING) {
  var contentString = '<div id="content">'+
                        '<div id="siteNotice">'+
                        '</div>'+
                        '<h3 id="firstHeading" class="firstHeading">Client: '+ID_CLIENTE+'</h3>'+
                        '<div id="bodyContent">'+
                          '<p><b>Route: </b>'+ID_RUTA+
                          '</p>'+
                          '<p><b>Address: </b>' + ESTADO + ', ' +
                                                    CIUDAD + ', ' +
                                                    CODIGO_POSTAL+ ', ' +
                                                    CALLE+
                          '</p>'+
                          '<p><b>Average rating: </b>' + PROMEDIO_RATING +
                          '</p>'+
                        '</div>'+
                      '</div>';

  var infoWindow = new google.maps.InfoWindow({
    content: contentString,
    maxWidth: 200
  });

  var marker = new google.maps.Marker({
    label: ID_RUTA,//markerElem.getAttribute('PROMEDIO_RATING'),
    map: map,
    //icon: image,
    //title: place.name,
    position: centro
  });

  marker.addListener('click', function() {
    infoWindow.open(map, marker);
  });

  markers.push(marker);
}

/*********************************************************************************************************************************/

function filterTable(event) {
    var filter = event.target.value.toUpperCase();
    var rows = document.querySelector("#tabla tbody").rows;
    
    for (var i = 0; i < rows.length; i++) {
        var clienteCol = rows[i].cells[0].textContent.toUpperCase();
        var rutaCol = rows[i].cells[1].textContent.toUpperCase();
        var estadoCol = rows[i].cells[2].textContent.toUpperCase();
        var ratingCol = rows[i].cells[4].textContent.toUpperCase();

        if (clienteCol.indexOf(filter) > -1 || rutaCol.indexOf(filter) > -1 || estadoCol.indexOf(filter) > -1 || ratingCol.indexOf(filter) > -1) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }      
    }
}

document.querySelector('#filtroTabla').addEventListener('keyup', filterTable, false);

/*********************************************************************************************************************************/

function filterSubTable_ID_CLIENTE(event) {
    var filter = event.target.value.toUpperCase();
    var rows = document.querySelector("#sub_tabla tbody").rows;
    
    for (var i = 0; i < rows.length; i++) {
        var lugarCol = rows[i].cells[0].textContent.toUpperCase();
        var ratingCol = rows[i].cells[1].textContent.toUpperCase();
        var distanciaCol = rows[i].cells[2].textContent.toUpperCase();
        var tipoCol = rows[i].cells[3].textContent.toUpperCase();

        if (lugarCol.indexOf(filter) > -1 || ratingCol.indexOf(filter) > -1 || distanciaCol.indexOf(filter) > -1 || tipoCol.indexOf(filter) > -1) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }      
    }
}

document.querySelector('#filtroSubTabla').addEventListener('keyup', filterSubTable_ID_CLIENTE, false);

/*********************************************************************************************************************************/

function td_ID_CLIENTE_onClick(ID_CLIENTE, LATITUD, LONGITUD){

  var div_div_sub_tabla = document.getElementById('div_div_sub_tabla');
  div_div_sub_tabla.setAttribute('style', 'visibility: visible;');


  console.log(ID_CLIENTE, LATITUD, LONGITUD);

  createSubTable_ID_CLIENTE(ID_CLIENTE, true);

  var centro = new google.maps.LatLng(LATITUD, LONGITUD);
        map.setZoom(15);
        map.panTo(centro);

  var radio = 500;

  var circulo = new google.maps.Circle({
      strokeColor: '#000000',
      strokeOpacity: 2,
      strokeWeight: 1,
      fillColor: '#819FF7',
      fillOpacity: 0,
      map: map,
      center: centro,
      radius: radio
    });
}

/*********************************************************************************************************************************/

function td_ID_RUTA_onClick(ID_CLIENTE, LATITUD, LONGITUD){

  var div_div_sub_tabla = document.getElementById('div_div_sub_tabla');
  div_div_sub_tabla.setAttribute('style', 'visibility: visible;');

  createSubTable_ID_CLIENTE(ID_CLIENTE, true);

  var centro = new google.maps.LatLng(LATITUD, LONGITUD);
        map.setZoom(9);
        map.panTo(centro);

  var radio = 500;

  var circulo = new google.maps.Circle({
      strokeColor: '#000000',
      strokeOpacity: 2,
      strokeWeight: 1,
      fillColor: '#819FF7',
      fillOpacity: 0,
      map: map,
      center: centro,
      radius: radio
    });


}

/*********************************************************************************************************************************/

function createSubTable_ID_CLIENTE(ID_CLIENTE, KEY){

  var myNode = document.getElementById("sub_tabla");
    while (myNode.firstChild) {
      myNode.removeChild(myNode.firstChild);
  }    

  downloadUrl('clientesLugares.xml', function(data) {
    var xml = data.responseXML;
    var markers = xml.documentElement.getElementsByTagName('marker');

    console.log(ID_CLIENTE);
    
    //Crear tabla y columnas de título
    var tabla = document.getElementById("sub_tabla");
    var tr_main_tabla = document.createElement("tr");
    var thead_tabla = document.createElement("thead");

    thead_tabla.setAttribute('style', 'height: 50px; ');

    var th_LUGAR = document.createElement("th");
    var th_RATING = document.createElement("th");
    var th_DISTANCIA = document.createElement("th");
    var th_TIPO = document.createElement("th");
    
    th_LUGAR.appendChild(document.createTextNode('NAME'));
    th_RATING.appendChild(document.createTextNode('RATING'));
    th_DISTANCIA.appendChild(document.createTextNode('DISTANCE'));
    th_TIPO.appendChild(document.createTextNode('TYPE'));

    th_LUGAR.setAttribute('style', 'text-align: center;');
    th_RATING.setAttribute('style', 'text-align: center;');
    th_DISTANCIA.setAttribute('style', 'text-align: center;');
    th_TIPO.setAttribute('style', 'text-align: center;');

    tr_main_tabla.appendChild(th_LUGAR);
    tr_main_tabla.appendChild(th_RATING);
    tr_main_tabla.appendChild(th_DISTANCIA);
    tr_main_tabla.appendChild(th_TIPO);

    thead_tabla.appendChild(tr_main_tabla);
    tabla.appendChild(thead_tabla);
    
    var tbody_tabla = document.createElement("tbody");

      //Por cada elemento marker
      Array.prototype.forEach.call(markers, function(markerElem) {
        var ID_CLIENTE_SUB = markerElem.getAttribute('ID_CLIENTE');
        var DISTANCIA = parseFloat(markerElem.getAttribute('DISTANCIA')).toFixed(0);

        if(ID_CLIENTE == ID_CLIENTE_SUB && DISTANCIA < 1000){
          //console.log(markerElem.getAttribute('LUGAR'));

          var LUGAR = markerElem.getAttribute('LUGAR');
          var RATING = markerElem.getAttribute('RATING');
          
          var TIPO = markerElem.getAttribute('TIPO');

          LUGAR = LUGAR.split('+').join(' ');
          LUGAR = LUGAR.split('%26').join('&');
          LUGAR = LUGAR.split('%27').join("'");
          LUGAR = LUGAR.split('%28').join("(");
          LUGAR = LUGAR.split('%29').join(")");
          LUGAR = LUGAR.split('%2F').join("/");
          LUGAR = LUGAR.split('%2B').join("+"); 
          LUGAR = LUGAR.split('%2C').join(",");
          LUGAR = LUGAR.split('%22').join('"');
          LUGAR = LUGAR.split('%C3%82').join("Â");
          LUGAR = LUGAR.split('%C3%A9').join("é");
          TIPO = TIPO.split(',').join(", ");
          TIPO = TIPO.split('_').join(" ");

          var tr_datos = document.createElement("tr");

          var td_LUGAR = document.createElement("td");
          var td_RATING = document.createElement("td");
          var td_DISTANCIA = document.createElement("td");
          var td_TIPO = document.createElement("td");

          td_LUGAR.appendChild(document.createTextNode(LUGAR));
          td_RATING.appendChild(document.createTextNode(RATING));
          td_DISTANCIA.appendChild(document.createTextNode(DISTANCIA));
          td_TIPO.appendChild(document.createTextNode(TIPO));

          td_LUGAR.setAttribute('style', 'text-align: left;');
          td_RATING.setAttribute('style', 'text-align: center;');
          td_DISTANCIA.setAttribute('style', 'text-align: center;');
          td_TIPO.setAttribute('style', 'text-align: left;');

          tr_datos.appendChild(td_LUGAR);
          tr_datos.appendChild(td_RATING);
          tr_datos.appendChild(td_DISTANCIA);
          tr_datos.appendChild(td_TIPO);

          tbody_tabla.appendChild(tr_datos);

          var centro_place = new google.maps.LatLng(
              parseFloat(markerElem.getAttribute('LAT_LUGAR')),
              parseFloat(markerElem.getAttribute('LNG_LUGAR'))
              );

            var r_0 = '#6E6E6E';//-1-0
            var r_1 = '#FF0000';//0-1
            var r_2 = '#FE9A2E';
            var r_3 = '#F4FA58';
            var r_4 = '#82FA58';
            var r_5 = '#58ACFA';

            var color;

            if(markerElem.getAttribute('RATING') < 0){
              color = r_0;
            }else if(markerElem.getAttribute('RATING') >= 0 && markerElem.getAttribute('RATING') < 1 ){
              color = r_1;
            }else if(markerElem.getAttribute('RATING') >= 1 && markerElem.getAttribute('RATING') < 2){
              color = r_2;
            }else if(markerElem.getAttribute('RATING') >= 2 && markerElem.getAttribute('RATING') < 3){
              color = r_3;
            }else if(markerElem.getAttribute('RATING') >= 3 && markerElem.getAttribute('RATING') < 4){
              color = r_4;
            }else if(markerElem.getAttribute('RATING') >= 4 && markerElem.getAttribute('RATING') <= 5){
              color = r_5;
            }

            var labelText = '<p>' + LUGAR + '</p>';
                            //'<p>' + markerElem.getAttribute('RATING') + '</p>';
            var myOptions = {
              content: labelText,
              maxWidth: "200px",
              boxStyle: {
                border: "none",
                textAlign: "center",
                fontSize: "8pt",
                background: color,
                opacity: "0.6",
                padding: "0px"
              },
              disableAutoPan: true,
              pixelOffset: new google.maps.Size(0, 0),
              position: centro_place,
              closeBoxURL: "",
              isHidden: false,
              pane: "mapPane",
              enableEventPropagation: true,
              zIndex: 10
            };

            var ibLabel = new InfoBox(myOptions);
            ibLabel.open(map);

        } 

      }); 

      tabla.appendChild(tbody_tabla);

    });     
}

/*********************************************************************************************************************************/

function createTable(){
  downloadUrl('clientesRating.xml', function(data) {
    var xml = data.responseXML;
    var markers = xml.documentElement.getElementsByTagName('marker');
    
    //Crear tabla y columnas de título
    var tabla = document.getElementById("tabla");
    var tr_main_tabla = document.createElement("tr");
    var thead_tabla = document.createElement("thead");

    thead_tabla.setAttribute('style', 'height: 50px; ');

    var th_ID_CLIENTE = document.createElement("th");
    var th_ID_RUTA = document.createElement("th");
    var th_ESTADO = document.createElement("th");
    var th_CODIGO_POSTAL = document.createElement("th");
    var th_PROMEDIO_RATING = document.createElement("th");
    
    th_ID_CLIENTE.appendChild(document.createTextNode('CLIENT'));
    th_ID_RUTA.appendChild(document.createTextNode('ROUTE'));
    th_ESTADO.appendChild(document.createTextNode('STATE'));
    th_CODIGO_POSTAL.appendChild(document.createTextNode('ZIP'));
    th_PROMEDIO_RATING.appendChild(document.createTextNode('AVG RATING'));

    th_ID_CLIENTE.setAttribute('style', 'text-align: center;');
    th_ID_RUTA.setAttribute('style', 'text-align: center;');
    th_ESTADO.setAttribute('style', 'text-align: center;');
    th_CODIGO_POSTAL.setAttribute('style', 'text-align: center;');
    th_PROMEDIO_RATING.setAttribute('style', 'text-align: center;');

    

    tr_main_tabla.appendChild(th_ID_CLIENTE);
    tr_main_tabla.appendChild(th_ID_RUTA);
    tr_main_tabla.appendChild(th_ESTADO);
    tr_main_tabla.appendChild(th_CODIGO_POSTAL);
    tr_main_tabla.appendChild(th_PROMEDIO_RATING);

    thead_tabla.appendChild(tr_main_tabla);
    tabla.appendChild(thead_tabla);


    var tbody_tabla = document.createElement("tbody");

    //Por cada elemento marker
    Array.prototype.forEach.call(markers, function(markerElem) {  
    
    //Asignación de las variables 
    var ID_CLIENTE = markerElem.getAttribute('ID_CLIENTE');
    var ID_RUTA = markerElem.getAttribute('ID_RUTA');
    var ESTADO = markerElem.getAttribute('ESTADO');
    var CODIGO_POSTAL = markerElem.getAttribute('CODIGO_POSTAL');
    var PROMEDIO_RATING = parseFloat(markerElem.getAttribute('PROMEDIO_RATING')).toFixed(1);
    var LATITUD = markerElem.getAttribute('LATITUD');
    var LONGITUD = markerElem.getAttribute('LONGITUD');

    var tr_datos = document.createElement("tr");

    var td_ID_CLIENTE = document.createElement("td");  
    var td_ID_RUTA = document.createElement("td");
    var td_ESTADO = document.createElement("td");
    var td_CODIGO_POSTAL = document.createElement("td");
    var td_PROMEDIO_RATING = document.createElement("td");

    //td_ID_CLIENTE.setAttribute('class', 'td_ID_CLIENTE');
    td_ID_CLIENTE.setAttribute('style', 'text-align: left;');

    //td_ID_RUTA.setAttribute('class', 'td_ID_CLIENTE');
    td_ID_RUTA.setAttribute('style', 'text-align: center;');

    //td_PROMEDIO_RATING.setAttribute('class', 'td_PROMEDIO_RATING');
    td_PROMEDIO_RATING.setAttribute('style', 'text-align: center;');

    //td_ESTADO.setAttribute('class', 'td_ESTADO');
    td_ESTADO.setAttribute('style', 'text-align: center;');

    td_ID_CLIENTE.setAttribute('onclick', 'td_ID_CLIENTE_onClick('+ID_CLIENTE+','+LATITUD+','+LONGITUD+');');
    td_ID_RUTA.setAttribute('onclick', 'td_ID_RUTA_onClick('+ID_CLIENTE+','+LATITUD+','+LONGITUD+');');

    td_ID_CLIENTE.appendChild(document.createTextNode(ID_CLIENTE));
    td_ID_RUTA.appendChild(document.createTextNode(ID_RUTA));
    td_ESTADO.appendChild(document.createTextNode(ESTADO));
    td_CODIGO_POSTAL.appendChild(document.createTextNode(CODIGO_POSTAL));
    td_PROMEDIO_RATING.appendChild(document.createTextNode(PROMEDIO_RATING));



    tr_datos.appendChild(td_ID_CLIENTE);
    tr_datos.appendChild(td_ID_RUTA);
    tr_datos.appendChild(td_ESTADO);
    tr_datos.appendChild(td_CODIGO_POSTAL);
    tr_datos.appendChild(td_PROMEDIO_RATING);

    

    
    tbody_tabla.appendChild(tr_datos);


    });

    tabla.appendChild(tbody_tabla);

  });
}
/*********************************************************************************************************************************/
function downloadUrl(url, callback) {    
  var request = window.ActiveXObject ?
      new ActiveXObject('Microsoft.XMLHTTP') :
      new XMLHttpRequest();

  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      //request.onreadystatechange = doNothing;
      callback(request, request.status);
    }
  };

  request.open('GET', url, true);
request.send(null);
}

/*********************************************************************************************************************************/